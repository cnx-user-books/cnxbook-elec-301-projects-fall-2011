function  [out, Anb, Bnb] = bokehblur2(i)
% layer = i;
% clear; close all;
path(path,genpath(pwd));


% I = double(imread('cameraman.tif'))/255;
I = double(imread('rice2.jpg'))/255;
I = I(:,:,i);
[m,n] = size(I);
%H = fspecial('motion',30,25);
H = fspecial('disk',5);

sigma = 1.e-3;
An = imfilter(I,H,'circular','conv');
%Bn = imfilter(I,H,'circular','conv') + sigma*randn(m,n);
Bn = imnoise(An, 'salt & pepper', 0.1);
% Bn = imnoise(An,'gaussian',0,0.00003);
%mu = 5.e4;
mu = 60;


%generate data -- see nested function below

snrBn = snr(Bn,I);
t = cputime;
%out = FTVd_v4(H,Bn,mu,'L2');
out = FTVd_v4(H,Bn,mu,'L1');
t = cputime - t;



bod = double(imread('riceboundary.jpg'))/255;
bod = bod(:,:,i);

%  Im = [1     1     1     1     1
%      1     1     0     1     1
%      1     0     0     0     1
%      1     0     1     1     0
%      0     1     1     1     1];
%  
% ind = zeros(1,size(Im,2));
bod(end,:) = zeros(1,size(bod,2));
for i = 1:size(bod,2)
    ind(i) = find(bod(:,i) == 0, 1);
    
end


u = size(out.sol,1);
v = size(out.sol,2);



for j = 1:v
    col = out.sol(:,j);
    bon = ind(j);
    
    col(bon:end) = I(bon:end,j);
    out.sol(:,j) = col;
end


Anb = [];
for j = 1:v
    col = An(:,j);
    bon = ind(j);
    
    col(bon:end) = I(bon:end,j);
    Anb(:,j) = col;
end

%Bnb = Anb + sigma*randn(m,n);
Bnb = imnoise(Anb, 'salt & pepper', 0.1);
%%
end
