function  [out, An, Bn] = bokehblur(layer,rad)
% layer = i;
% clear; close all;
path(path,genpath(pwd));


% I = double(imread('cameraman.tif'))/255;
I = double(imread('rice2.jpg'))/255;
I = I(:,:,layer);
[m,n] = size(I);
%H = fspecial('motion',rad,60);
H = fspecial('disk',rad);

sigma = 1.e-3;
An = imfilter(I,H,'circular','conv');
%Bn = imfilter(I,H,'circular','conv') + sigma*randn(m,n);
Bn = imnoise(An, 'salt & pepper', 0.1);
% Bn = imnoise(An,'gaussian',0,0.00003);
%mu = 5.e4;
mu = 60;


%generate data -- see nested function below

snrBn = snr(Bn,I);
t = cputime;
%out = FTVd_v4(H,Bn,mu,'L2');
out = FTVd_v4(H,Bn,mu,'L1');
t = cputime - t;
% figure
% imshow(An,[])
% figure
% subplot(221);
% imshow(I,[]);
% title('original image');
% subplot(222);
% imshow(An,[]);
% title('blured image');
% subplot(223);
% imshow(Bn,[]);
% title('blured with noise image');
% subplot(224);
% imshow(out.sol,[])
% title('restored image');

end






