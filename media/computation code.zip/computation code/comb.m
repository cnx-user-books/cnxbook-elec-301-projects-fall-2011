clear all;
result=[];
for j = 1:0.5:20
finalout = [];
psnr = [];
[out1, An1, Bn1]  = bokehblur(1,j);
% [out2, An2, Bn2]  = bokehblur(2,j);
% [out3, An3, Bn3]  = bokehblur(3,j);
finalout(:,:,1) = out1.sol;
% finalout(:,:,2) = out2.sol;
% finalout(:,:,3) = out3.sol;
An(:,:,1) = An1;
% An(:,:,2) = An2;
% An(:,:,3) = An3;
Bn(:,:,1) = Bn1;
% Bn(:,:,2) = Bn2;
% Bn(:,:,3) = Bn3;
% % subplot(221);
% 
I = double(imread('rice2.jpg'))/255;

I = I(:,:,1);
% figure
% imshow(I);
% title('original image')
% 
% % subplot(222);
% %figure
% %imshow(An);
% %title('blurred image')
% 
% %subplot(223);
% figure
% imshow(Bn);
% title('blurred with noise image')
% 
% %subplot(224);
% figure
% imshow(finalout);
% title('deblurred image');


diff = I - finalout;
db = 20*log10(1/(sqrt(mean(mean(diff.^2)))));
out.psnr = db;
disp(j);
disp(sprintf('PSNR = +%5.2f dB',db));
result = [result;out.psnr];
end
