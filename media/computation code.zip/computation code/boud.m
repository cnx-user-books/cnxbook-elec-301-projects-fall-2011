bod = double(imread('riceboundary.jpg'))/255;
bod = bod(:,:,1);

%  Im = [1     1     1     1     1
%      1     1     0     1     1
%      1     0     0     0     1
%      1     0     1     1     0
%      0     1     1     1     1];
%  
% ind = zeros(1,size(Im,2));
bod(end,:) = zeros(1,size(bod,2));
for i = 1:size(bod,2)
    ind(i) = find(bod(:,i) == 0, 1);
    
end


u = size(out.sol,1);
v = size(out.sol,2);



for j = 1:v
    col = out.sol(:,j);
    bon = ind(j);
    
    col(bon:end) = I(bon:end,j);
    out.sol(:,j) = col;
end
 
imshow(out.sol,[]);

